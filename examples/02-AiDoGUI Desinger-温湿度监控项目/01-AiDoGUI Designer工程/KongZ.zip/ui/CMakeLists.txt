SET(SOURCES
    "${CMAKE_CURRENT_SOURCE_DIR}/components/ui_comp.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/components/ui_comp_hook.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/ui.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/ui_helpers.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/ui_comm.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_fonts.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/animations/ui_animations.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/screens/ui_screen1.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/events/aido_event_screen1.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/screens/ui_screen2.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/events/aido_event_screen2.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/screens/ui_screen3.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/events/aido_event_screen3.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/screens/ui_screen4.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/events/aido_event_screen4.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/screens/ui_screen5.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/events/aido_event_screen5.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/screens/ui_screen6.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/events/aido_event_screen6.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_aidaid_jpg.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_bluetooth_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_weather_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_wenfile_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_wifi_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_frame_07_delay_0_1s_jpg.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_frame_07_delay_0_1s_1_jpg.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_frame_07_delay_0_1s_2_jpg.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_frame_07_delay_0_1s_3_jpg.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_frame_07_delay_0_1s_4_jpg.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_frame_07_delay_0_1s_5_jpg.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_gerenshezhi_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_seo_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_wengaobaoshencailiao_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_wodeshoucang_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_yonghuzu_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_zhandianliebiao_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_huishouzhan_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_riqirili_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_humidityhu_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_temperaturete_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_cpucpu_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/images/ui_img_voltmeter_v_png.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_50.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_30.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_24.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_46.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_40.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font__aidogui_default_alibaba__16.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_36.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_100.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/fonts/ui_font_alimama_fang_yuan_ti_vf_thin_20.c"
    "${CMAKE_CURRENT_SOURCE_DIR}/custom/custom.c"
)

file(GLOB_RECURSE AIDOGUI_USER_SOURCES CONFIGURE_DEPENDS "custom/*.c")
foreach(USER_SOURCE IN LISTS AIDOGUI_USER_SOURCES)
    string(TOLOWER "${USER_SOURCE}" LOWER_USER_SOURCE)
    # 旧扩展注册文件保留在磁盘供用户迁移，但不能链接进新代码。
    if(NOT LOWER_USER_SOURCE MATCHES "/custom/(user/(aidogui_user_hooks\\.c|simulator/aidogui_user_simulator\\.c)|project/(aidogui_project_hooks\\.c|simulator/aidogui_project_simulator\\.c))$")
        list(APPEND SOURCES "${USER_SOURCE}")
    endif()
endforeach()
list(REMOVE_DUPLICATES SOURCES)
add_library(ui ${SOURCES})
target_include_directories(ui PUBLIC ${CMAKE_CURRENT_SOURCE_DIR} "${CMAKE_CURRENT_SOURCE_DIR}/custom")
if(TARGET lvgl::lvgl)
    target_link_libraries(ui PUBLIC lvgl::lvgl)
elseif(TARGET lvgl)
    target_link_libraries(ui PUBLIC lvgl)
endif()
